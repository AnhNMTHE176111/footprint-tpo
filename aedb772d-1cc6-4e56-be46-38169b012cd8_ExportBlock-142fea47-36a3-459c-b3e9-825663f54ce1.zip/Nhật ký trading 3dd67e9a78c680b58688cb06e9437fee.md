# Nhật ký trading

# 16/9 | -1R

![Sell | Sell chủ động + Follow | SL -0.5R
Be sớm quá, sau đó đạt đúng target, thậm chí là 3R
⇒ Phải Kiên nhẫn chờ
Kể cả sau khi entry, giá dập dình 1 lúc mới chịu xuống TP](image.png)

Sell | Sell chủ động + Follow | SL -0.5R
Be sớm quá, sau đó đạt đúng target, thậm chí là 3R
⇒ Phải Kiên nhẫn chờ
Kể cả sau khi entry, giá dập dình 1 lúc mới chịu xuống TP

![Sell | Cảm thấy buy ko lên nổi + nến sell xuống | SL -1R
Ko tuân thủ rule, ko có signal, hoàn toàn là cảm giác về nến
Trước đó có cây sập rất mạnh nhưng giá vẫn đóng lên trên
Giá chạm vào Độ lệch chuẩn của VWAP và có sập xuống nhưng vẫn đủ mạnh để rút râu
⇒ lực buy rất mạnh ở đây
⇒ Phải tuân thủ rule, loại bỏ cảm giác](image%201.png)

Sell | Cảm thấy buy ko lên nổi + nến sell xuống | SL -1R
Ko tuân thủ rule, ko có signal, hoàn toàn là cảm giác về nến
Trước đó có cây sập rất mạnh nhưng giá vẫn đóng lên trên
Giá chạm vào Độ lệch chuẩn của VWAP và có sập xuống nhưng vẫn đủ mạnh để rút râu
⇒ lực buy rất mạnh ở đây
⇒ Phải tuân thủ rule, loại bỏ cảm giác

![Buy | Cảm giác buy | TP +2R
Trước đó là nến pin bar buy thể hiện lực bán mạnh nhưng thất bại ⇒ PRice action
Hoàn toàn ko follow theo rule của các concept, ko hề có bóng xuất hiện
⇒ Phải tuân theo các rule và các tiêu chí của concept](image%202.png)

Buy | Cảm giác buy | TP +2R
Trước đó là nến pin bar buy thể hiện lực bán mạnh nhưng thất bại ⇒ PRice action
Hoàn toàn ko follow theo rule của các concept, ko hề có bóng xuất hiện
⇒ Phải tuân theo các rule và các tiêu chí của concept

![Buy | Phá + hồi + đỏ đít + nến confirm xanh mạnh | SL -2R
Lỗi nhồi lệnh ⇒ nghiêm cấm
Đúng rule để entry nhưng bị fail, ko sao cả, setup vẫn có thể SL
Sau khi đấu giá thất bại fail thì nó chạy về VA và sang cạnh đối diện VA
⇒ Cấm nhồi lệnh](image%203.png)

Buy | Phá + hồi + đỏ đít + nến confirm xanh mạnh | SL -2R
Lỗi nhồi lệnh ⇒ nghiêm cấm
Đúng rule để entry nhưng bị fail, ko sao cả, setup vẫn có thể SL
Sau khi đấu giá thất bại fail thì nó chạy về VA và sang cạnh đối diện VA
⇒ Cấm nhồi lệnh

![Sell | đấu giá thất bại + quay về VA + nến cf giảm delta đẹp | TP +2R](image%204.png)

Sell | đấu giá thất bại + quay về VA + nến cf giảm delta đẹp | TP +2R

![Buy | Thấy có cặp nến engulfing + nến cf tăng có delta xanh mạnh | SL -1R
Bối cảnh vẫn là giảm, và ko có đỏ đít thể hiện hấp thụ để đảo chiều
⇒ Vẫn bị sai lầm price action](image%205.png)

Buy | Thấy có cặp nến engulfing + nến cf tăng có delta xanh mạnh | SL -1R
Bối cảnh vẫn là giảm, và ko có đỏ đít thể hiện hấp thụ để đảo chiều
⇒ Vẫn bị sai lầm price action

![Sell | Xanh đầu + nến cf bán mạnh | SL -0.5R
Thấy giá đi được 1R (nhưng rút râu), sốt ruột, kéo 0.5R
Bị be -0.5R rồi giá chạy xuống, thậm chí TP 3R
⇒ kiên nhẫn chờ đợi](image%206.png)

Sell | Xanh đầu + nến cf bán mạnh | SL -0.5R
Thấy giá đi được 1R (nhưng rút râu), sốt ruột, kéo 0.5R
Bị be -0.5R rồi giá chạy xuống, thậm chí TP 3R
⇒ kiên nhẫn chờ đợi

![Sell | Hấp thụ buy + nến cf giảm delta âm | SL +0R
Nến tăng +110, nhưng giá ko lên ⇒ hấp thụ
expect TP 3R, giá đi đươc 2R be hòa
KO để ý nến -242 và đỏ đít ⇒ hấp thụ sell ⇒ ko chịu chốt lời ⇒ bị be hòa
⇒ Để ý giá đang chạy, nếu cảm thấy TP bị đe dọa bởi hấp thụ ⇒ chốt ngay](image%207.png)

Sell | Hấp thụ buy + nến cf giảm delta âm | SL +0R
Nến tăng +110, nhưng giá ko lên ⇒ hấp thụ
expect TP 3R, giá đi đươc 2R be hòa
KO để ý nến -242 và đỏ đít ⇒ hấp thụ sell ⇒ ko chịu chốt lời ⇒ bị be hòa
⇒ Để ý giá đang chạy, nếu cảm thấy TP bị đe dọa bởi hấp thụ ⇒ chốt ngay

# 17/9 | +6R

![Buy | Phá hồi + nến cf sau nến buy tăng mạnh | TP + 2R](image%208.png)

Buy | Phá hồi + nến cf sau nến buy tăng mạnh | TP + 2R

![Sell | Xanh đầu + nến cf giảm delta âm mạnh | SL -1R
Move tăng sau nhịp phá có:
  • DMA tăng 
  • Có độ dốc mạnh
 ⇒ thuận chiều, ko phân kì
⇒ chưa thể hiện sự hấp thụ gì cả, cản tàu là đứt tay](image%209.png)

Sell | Xanh đầu + nến cf giảm delta âm mạnh | SL -1R
Move tăng sau nhịp phá có:
  • DMA tăng 
  • Có độ dốc mạnh
 ⇒ thuận chiều, ko phân kì
⇒ chưa thể hiện sự hấp thụ gì cả, cản tàu là đứt tay

![Buy | nến tăng mạnh trong move delta +120 | SL -1R
Nhìn vào TPO tuần, hiên tại giá đã chạm vào LVN ở tuần trước (4420-4425)
Giá sẽ từ chối ở đấy ⇒ nên ngưng fomo
⇒ Biết cách đọc TPO tuần và ngày](image%2010.png)

Buy | nến tăng mạnh trong move delta +120 | SL -1R
Nhìn vào TPO tuần, hiên tại giá đã chạm vào LVN ở tuần trước (4420-4425)
Giá sẽ từ chối ở đấy ⇒ nên ngưng fomo
⇒ Biết cách đọc TPO tuần và ngày

![TPO tuần (bắt đầu build từ mỗi thứ 2)](image%2011.png)

TPO tuần (bắt đầu build từ mỗi thứ 2)

![Sell | Xanh đầu + sell chủ động vào + delta -64 | TP +2R](image%2012.png)

Sell | Xanh đầu + sell chủ động vào + delta -64 | TP +2R

![Buy | Đỏ đít + Follow | TP +2R
Có thể vào luôn ở nến +67 nhưng ko để ý và vào muộn](image%2013.png)

Buy | Đỏ đít + Follow | TP +2R
Có thể vào luôn ở nến +67 nhưng ko để ý và vào muộn

![Sell | Trap buy + Nến cf đóng dưới delta -41 | TP +2R](image%2014.png)

Sell | Trap buy + Nến cf đóng dưới delta -41 | TP +2R

![Sell | Đặt sell limit tại vùng trap buy cũ trong VA mới | TP +3R](image%2015.png)

Sell | Đặt sell limit tại vùng trap buy cũ trong VA mới | TP +3R

![Buy | Đỏ đít + Follow | TP +2R
Sau đỏ đít và chờ follow, đợi nó bóp SL nhưng hơi chậm](image%2016.png)

Buy | Đỏ đít + Follow | TP +2R
Sau đỏ đít và chờ follow, đợi nó bóp SL nhưng hơi chậm

![Buy | Fomo buy + nhồi lệnh | SL -1R
Sau khi thấy nến tăng mạnh +96 và thấy cây nến giảm -22 ko làm yếu được move nên entry buy nhồi lệnh
Đồng thời cũng ko có bóng xanh hay đỏ tín hiệu gì cả, vẫn đang trong range
⇒ Tuyệt đối ko nhồi lệnh](image%2017.png)

Buy | Fomo buy + nhồi lệnh | SL -1R
Sau khi thấy nến tăng mạnh +96 và thấy cây nến giảm -22 ko làm yếu được move nên entry buy nhồi lệnh
Đồng thời cũng ko có bóng xanh hay đỏ tín hiệu gì cả, vẫn đang trong range
⇒ Tuyệt đối ko nhồi lệnh

![Buy | Nến cf +60 sau nến tăng mạnh dài đẹp +143 | SL -1R
Giá đã tới đỉnh range, ko phá đỉnh, ko có bóng thể hiện phe mạnh vào
⇒ Đang trong range thì chỉ chơi fade 2 cạnh](image%2018.png)

Buy | Nến cf +60 sau nến tăng mạnh dài đẹp +143 | SL -1R
Giá đã tới đỉnh range, ko phá đỉnh, ko có bóng thể hiện phe mạnh vào
⇒ Đang trong range thì chỉ chơi fade 2 cạnh

![Buy | xanh đít phe bán lao vào và nến confirm tăng | SL -1R
Bối cảnh vẫn đang ở đỉnh range, giá vẫn đang còn lao xuống dưới cạnh dưới của range
Nếu nó xảy ra ở đáy range thì có thể entry được đẹp
⇒ Tôn trọng bối cảnh của range, nếu chưa phá, thì chỉ fade 2 cạnh](Screenshot_2026-09-18_111015.png)

Buy | xanh đít phe bán lao vào và nến confirm tăng | SL -1R
Bối cảnh vẫn đang ở đỉnh range, giá vẫn đang còn lao xuống dưới cạnh dưới của range
Nếu nó xảy ra ở đáy range thì có thể entry được đẹp
⇒ Tôn trọng bối cảnh của range, nếu chưa phá, thì chỉ fade 2 cạnh

![Buy | Fomo buy | SL -1R
⇒ Tôn trọng bối cảnh của range, nếu chưa phá thì chỉ fade 2 cạnh](image%2019.png)

Buy | Fomo buy | SL -1R
⇒ Tôn trọng bối cảnh của range, nếu chưa phá thì chỉ fade 2 cạnh

![Sell | Xanh đầu + nến cf giảm đẹp | SL -0R
Được 1 R thì be hòa, chạm TP nhưng quay lại be hòa ⇒ cay vcl exness
⇒ tôn trọng 2 cạnh, nếu entry sớm hơn tại -52 thì ok](image%2020.png)

Sell | Xanh đầu + nến cf giảm đẹp | SL -0R
Được 1 R thì be hòa, chạm TP nhưng quay lại be hòa ⇒ cay vcl exness
⇒ tôn trọng 2 cạnh, nếu entry sớm hơn tại -52 thì ok

![Sell | Thấy sell nhiều và move giảm | SL -1R
Sell nhiều, nhưng bị đỏ đít, hơi nguy hiểm](image%2021.png)

Sell | Thấy sell nhiều và move giảm | SL -1R
Sell nhiều, nhưng bị đỏ đít, hơi nguy hiểm

![Buy | Đỏ đít + nến xanh có buy + rút râu dưới | SL -1R
⇒ muốn đảo chiều nhưng chưa chạm tới cạnh dưới của range
Xanh đấy cũng có thể là trap buy
⇒ Chờ vào bối cảnh chính xác của range thì sẽ mạnh hơn](image%2022.png)

Buy | Đỏ đít + nến xanh có buy + rút râu dưới | SL -1R
⇒ muốn đảo chiều nhưng chưa chạm tới cạnh dưới của range
Xanh đấy cũng có thể là trap buy
⇒ Chờ vào bối cảnh chính xác của range thì sẽ mạnh hơn

![Sell | Follow sell + trap buy | TP +3R
Entry đẹp:
  • 1 move giảm
  • nhịp hồi lên
  • bóng xanh đỉnh
  • nến cf giảm đẹp có đỏ đỉnh chủ động](image%2023.png)

Sell | Follow sell + trap buy | TP +3R
Entry đẹp:
  • 1 move giảm
  • nhịp hồi lên
  • bóng xanh đỉnh
  • nến cf giảm đẹp có đỏ đỉnh chủ động

![Sell | Phá hồi + đỏ đỉnh bán chủ động | SL -1R
⇒ move giả trước đó đã chạm vùng và bị hấp thụ:
  • Delta vừa giảm dần
  • Nến vừa ngắn dần
  • Và bị gãy tại nến tăng +43
  • Bán nhiều nhưng ko có kết quả ⇒ hấp thụ
 ⇒ hãy trực tiếp đánh giá move trước đó khi chạm vùng để nắm hành vi](image%2024.png)

Sell | Phá hồi + đỏ đỉnh bán chủ động | SL -1R
⇒ move giả trước đó đã chạm vùng và bị hấp thụ:
  • Delta vừa giảm dần
  • Nến vừa ngắn dần
  • Và bị gãy tại nến tăng +43
  • Bán nhiều nhưng ko có kết quả ⇒ hấp thụ
 ⇒ hãy trực tiếp đánh giá move trước đó khi chạm vùng để nắm hành vi

![Buy | Sau nến tăng mạnh + nến cf tăng +30 | SL -1R
Sau nến tăng mạnh ⇒ hãy kiên nhẫn chờ giá hồi về, ko thì hãy bỏ qua
Bởi vì dù có entry ở đấy thì giá cũng đã chạy rồi, nó nằm ở lưng rồi, thiếu điểm tựa để SL
Và giá cũng đã hồi về ngay tại chỗ nó bắt đầu tăng mạnh rồi đi vọt thẳng lên đó
⇒ Hãy kiên nhẫn trước những nến tăng/giảm mạnh và dài nhé](image%2025.png)

Buy | Sau nến tăng mạnh + nến cf tăng +30 | SL -1R
Sau nến tăng mạnh ⇒ hãy kiên nhẫn chờ giá hồi về, ko thì hãy bỏ qua
Bởi vì dù có entry ở đấy thì giá cũng đã chạy rồi, nó nằm ở lưng rồi, thiếu điểm tựa để SL
Và giá cũng đã hồi về ngay tại chỗ nó bắt đầu tăng mạnh rồi đi vọt thẳng lên đó
⇒ Hãy kiên nhẫn trước những nến tăng/giảm mạnh và dài nhé

# 18/9 | +0R

![Sell | Fade đỉnh trong range | TP +2R](image%2026.png)

Sell | Fade đỉnh trong range | TP +2R

![Sell | Fade đáy trong range | SL -1R
  • Nến ngắn, tăng ko mạnh
⇒ chú ý thân nến](image%2027.png)

Sell | Fade đáy trong range | SL -1R
  • Nến ngắn, tăng ko mạnh
⇒ chú ý thân nến

![Sell | Phá range + hồi + nến cf dài đẹp | SL -1R
Đúng setup cũng có thể thua, tuy nhiên thì lại ko biết đánh giá mức độ move trước đó
  • Move giảm
  • Có nến giảm mạnh
  • Có bóng nến đỏ liên tục
  • Nhưng thân nến giảm + delta giảm dần
 ⇒ Hấp thụ
Và chỉ cần 1 nhịp nữa đỏ đít + xanh cf là vào entry đẹp 3R](image%2028.png)

Sell | Phá range + hồi + nến cf dài đẹp | SL -1R
Đúng setup cũng có thể thua, tuy nhiên thì lại ko biết đánh giá mức độ move trước đó
  • Move giảm
  • Có nến giảm mạnh
  • Có bóng nến đỏ liên tục
  • Nhưng thân nến giảm + delta giảm dần
 ⇒ Hấp thụ
Và chỉ cần 1 nhịp nữa đỏ đít + xanh cf là vào entry đẹp 3R

# 21/9 | +1R

![Sell | move giảm + nến xanh + nến đỏ bẻ gãy ⇒ Follow sell | TP +4R](image%2029.png)

Sell | move giảm + nến xanh + nến đỏ bẻ gãy ⇒ Follow sell | TP +4R

![Buy | Fade đáy trong range | SL -1R
⇒ chú ý khi fade đỉnh/đáy: delta phải xanh/đỏ ủng hộ thì mới được vào

Sell | Đổi bias vì thấy buy ko lên nổi | SL -1R
⇒ vẫn đang ở cạnh dưới của range, tốt nhất cứ đợi phá hẳn rồi vào
Đứng ở cạnh này ko rõ ràng, thay đổi bias liên tục](image%2030.png)

Buy | Fade đáy trong range | SL -1R
⇒ chú ý khi fade đỉnh/đáy: delta phải xanh/đỏ ủng hộ thì mới được vào

Sell | Đổi bias vì thấy buy ko lên nổi | SL -1R
⇒ vẫn đang ở cạnh dưới của range, tốt nhất cứ đợi phá hẳn rồi vào
Đứng ở cạnh này ko rõ ràng, thay đổi bias liên tục

![Sell | giá lên ko nổi + nến cf giảm đẹp | +0R
  • Be hòa thì bị be
  • Target 3R thì chạm đúng 2R rồi quay lại be
  • Phá hồi | Hấp thụ ⇒ 3R
  • Follow ⇒ 2R](image%2031.png)

Sell | giá lên ko nổi + nến cf giảm đẹp | +0R
  • Be hòa thì bị be
  • Target 3R thì chạm đúng 2R rồi quay lại be
  • Phá hồi | Hấp thụ ⇒ 3R
  • Follow ⇒ 2R

![image.png](image%2032.png)

Đọc giá chạy Swing ở TPO tuần:

- Giá đấu giá ở POC 4390
- POC ở gần VAL nên có thể giá sẽ down
- Khi giá down xuống thì sẽ chạm vào cạnh dưới của LVN tuần trước, và bật ngược lại

⇒ Như vậy, khi thấy giá di chuyển tạo move mạnh, có thể swing và target xa tới các LVN của tuần trước đó nhé

![image.png](image%2033.png)

# 22/9

![Sell | Bias day sell + gần vwap + nến giảm dài | SL -1R](image%2034.png)

Sell | Bias day sell + gần vwap + nến giảm dài | SL -1R

# 23/9

# 24/9

# 25/9